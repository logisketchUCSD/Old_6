BP Bartender - GUI application for the backpropagation network

BP Bar (training) - training applicaion for the backpropagation network
   Command Line: BPBar -n 0.01 -e 0.00001 -l 500000 -m 0 -t 0 -nn cocktails.nn -i cocktails.in

Drink Vectors - XML of drink vectors I used. The top 80 are for training, the bottom 30 were for testing
* In order to use the vectors you have to copy the numbers into a .in file format
* BPBar\bin\Debug\cocktails.in = 80 training vectors, test.in = 30 test vectors